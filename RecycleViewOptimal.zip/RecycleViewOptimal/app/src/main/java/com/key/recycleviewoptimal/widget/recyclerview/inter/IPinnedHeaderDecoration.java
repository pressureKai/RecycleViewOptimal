package com.key.recycleviewoptimal.widget.recyclerview.inter;

import android.graphics.Rect;

public interface IPinnedHeaderDecoration {

	Rect getPinnedHeaderRect();

	int getPinnedHeaderPosition();

}
