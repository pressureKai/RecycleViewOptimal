package com.key.recycleviewoptimal.widget.recyclerview.base;

/**
 * created by key  on 2019/7/17
 */
public class ConstantValues {

    public static final int PAGESIZE = 10;
}
